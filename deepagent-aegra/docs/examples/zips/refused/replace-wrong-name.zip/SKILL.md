---
name: some-other-skill
description: A sample
---
Do nothing.
