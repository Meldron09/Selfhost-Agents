---
name: stray-png
description: A sample
---
Do nothing.
